This addon was created by XSI 4.2, and it may or may not work with earlier versions of XSI.

How to install - two ways:
Open SoftImage and drag "Pandemic Tools.xsiaddon" onto the SoftImage window.  It will install automatically.
--or--
In SoftImage, go to File, AddOn, Install, then browse to find "Pandemic Tools.xsiaddon" and click Install.

